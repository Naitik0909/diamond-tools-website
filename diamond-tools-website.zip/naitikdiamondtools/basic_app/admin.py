from django.contrib import admin
from basic_app.models import Product, QueryBox
# Register your models here.
admin.site.register(Product)
admin.site.register(QueryBox)
